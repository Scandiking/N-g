import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import AddTask from './AddTask';
import AddPeople from './AddPeople';
import AddRoom from './AddRoom';
import {Avatar, ListItemIcon, SwipeableDrawer} from "@mui/material";
import HomeIcon from '@mui/icons-material/Home';
import TaskIcon from '@mui/icons-material/Task';
import PeopleIcon from '@mui/icons-material/People';
import RoomIcon from '@mui/icons-material/Room';
import LeaderboardIcon from '@mui/icons-material/Leaderboard';
import SettingsIcon from '@mui/icons-material/Settings';

// import Statistics from './Statistics';
// import Settings from './Settings';

const Header = () => {
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);
    const [isAddPeopleModalOpen, setIsAddPeopleModalOpen] = useState(false);
    const [isAddRoomsModalOpen, setIsAddRoomsModalOpen] = useState(false);
    const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
    const navigate = useNavigate();

    // Function to toggle the drawer state
    const toggleDrawer = (open) => (event) => {
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
            return;
        }
        setIsDrawerOpen(open);
    };

    const toggleAddTaskModal = (open) => {
        setIsAddTaskModalOpen(open);
    };

    const toggleAddPeopleModal = (open) => {
        setIsAddPeopleModalOpen(open);
    }

    const toggleAddRoomsModal = (open) => {
        setIsAddRoomsModalOpen(open);
    }

    const toggleSettingsModal = (open) => {
        setIsSettingsModalOpen(open);
    }

    return (
        <>
            <AppBar position="fixed">
                <Toolbar>
                    <IconButton edge="start" color="inherit" aria-label="menu" onClick={toggleDrawer(true)}>
                        <MenuIcon />
                    </IconButton>
                    <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                        Næg
                    </Typography>
                    <Avatar alt="Kristian Martin Tvenning" src="/static/images/avatar/1.jpg"/>
                </Toolbar>


            </AppBar>

            {/* This box creates space equal to the AppBar height */}
            {/* Trenger denne boksen for at kortene ikke skal havne under app-baren */}
            <Box sx={{ marginTop: '64px' }}> {/*Adjust the marginTop value if needed*/}</Box>

            { /* Dette er sideskuffen med manipulering */ }
            <SwipeableDrawer
                swipeAreaWidth={10}
                anchor="left"
                open={isDrawerOpen}
                onClose={toggleDrawer(false)}>

                {/* I sideskuffen er det en liste med valg*/}
                <List>
                    <ListItem
                        button
                        onClick = {() => {
                            setIsDrawerOpen(false);
                            navigate("/");
                        }}
                        >
                        <ListItemIcon>
                            <HomeIcon />
                        </ListItemIcon>
                        <ListItemText primary="Home"/>
                    </ListItem>

                    <ListItem
                        // Legg til oppgave
                        button
                        onClick={() => {
                            setIsDrawerOpen(false);
                            toggleAddTaskModal(true);
                            console.log('Add Task Modal open', isAddTaskModalOpen);
                        }}
                    >
                        <ListItemIcon>
                            <TaskIcon />
                        </ListItemIcon>
                        <ListItemText primary="Add tasks" />
                    </ListItem>
                    <ListItem
                        // Legg til folk
                        button
                        onClick={() => {
                            setIsDrawerOpen(false);
                            toggleAddPeopleModal(true);
                        }}
                    >
                        <ListItemIcon>
                            <PeopleIcon/>
                        </ListItemIcon>
                        <ListItemText primary="Add people" />
                    </ListItem>

                    <ListItem
                        button
                        onClick={ () => {
                            setIsDrawerOpen(false);
                            toggleAddRoomsModal(true);
                        }}
                        >
                        <ListItemIcon>
                            <RoomIcon/>
                        </ListItemIcon>
                        <ListItemText primary="Add room"/>
                    </ListItem>

                    <ListItem
                        // Statistikk
                        button
                        onClick={() => {
                            setIsDrawerOpen(false);
                            console.log('Statistics clicked');
                            navigate('/statistics');
                        // Add nagivation or additional functionality here}
                        }}
                    >
                        <ListItemIcon>
                            <LeaderboardIcon/>
                        </ListItemIcon>
                        <ListItemText primary="Statistics"/>
                    </ListItem>

                    <ListItem
                        // Innstillinger
                        button
                        onClick={() => {
                            setIsDrawerOpen(false);
                            navigate('/settings');
                        }}
                    >
                        <ListItemIcon>
                            <SettingsIcon/>
                        </ListItemIcon>
                        <ListItemText primary="Settings" />
                    </ListItem>

                </List>
            </SwipeableDrawer>


            { /* MODAL-VALG */}
            { /* Legg til oppgave */}
            <Modal
                open={isAddTaskModalOpen}
                onClose={() => toggleAddTaskModal(false)}
                aria-labelledby="add-task-modal"
                aria-describedby="add-task-modal-description"
            >
                <Box
                    sx={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        width: 400,
                        p: 4,
                        borderRadius: 8
                    }}
                >
                    <AddTask />
                </Box>
            </Modal>

            <Modal
                // Legg til folk
                open={isAddPeopleModalOpen}
                onClose={() => toggleAddPeopleModal(false)}
                aria-labelledby="add-people-modal"
                aria-describedby="add-people-modal-description"
            >
                <Box
                    sx={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        width: 400,
                        p: 4
                    }}
                >
                    <AddPeople />
                </Box>
            </Modal>

            <Modal
                // Legg til rom
                open={isAddRoomsModalOpen}
                onClose = {() => toggleAddRoomsModal(false)}
                aria-labelledby = "add-rooms-modal"
                aria-describedby="add-rooms-modal-description"
            >
                <Box
                    sx={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        width: 400,
                        p: 4
                    }}
                >
                    <AddRoom />
                </Box>
            </Modal>

            <Modal
                // Settings
                open={isSettingsModalOpen}
                onClose = {() => toggleSettingsModal(false)}
                aria-labelledby = "settings-modal"
                aria-describedby="settings-modal-description"
            >
                <List>
                    <ListItem>
                        <ListItemText>
                            hehe
                        </ListItemText>
                    </ListItem>
                </List>
            </Modal>
        </>
    );
};

export default Header;