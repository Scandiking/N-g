// ThemeContext.jsx should handle the theme state (mode) and provide functions (setMode) to update it


import React, { createContext, useState, useEffect, useCallback } from 'react';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

export const ThemeContext = createContext();

const ThemeContextProvider = ({ children }) => {
    const [mode, setMode] = useState('auto');

    // Determine the theme mode
    const getThemeMode = useCallback(() => {
        if (mode === 'auto') {
            return window.matchMedia('prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        }
        return mode;
        }, [mode]);

    // Update the body's data-theme attribute when the mode changes
    useEffect(() => {
        document.body.setAttribute('data-theme', getThemeMode());
    }, [getThemeMode]);

    // Provide the theme state and updater function
    return (
        <ThemeContext.Provider value={{mode, setMode, getThemeMode }}>
            {children}
        </ThemeContext.Provider>
    );
};


export default ThemeContextProvider;