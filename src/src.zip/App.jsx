import {BrowserRouter, Route, Routes} from "react-router-dom";
import Statistics from "./Statistics";

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<div>Home Page</div>} />
                <Route path="/statistics" element={<Statistics />} />
            </Routes>
        </BrowserRouter>
    );
}

export default App;
