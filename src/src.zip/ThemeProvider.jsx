// ThemeProvider.jsx appplying that state to Material-UI's Theme Provider

import React, {createContext, useState, useEffect, useCallback, useContext} from 'react';
import { ThemeProvider as MuiThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { ThemeContext } from './ThemeContext';

const ThemeProvider = ({ children }) => {
    const { getThemeMode } = useContext(ThemeContext);

    const theme = createTheme({
        palette: {
            mode: getThemeMode(),
        },
    });

    return (
        <MuiThemeProvider theme={theme}>
            <CssBaseline />
            {children}
        </MuiThemeProvider>
    );
};

export default ThemeProvider;