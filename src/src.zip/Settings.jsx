import React, {useContext} from 'react';
import { RadioGroup, FormControlLabel, Radio} from '@mui/material';
import AutoModeIcon from '@mui/icons-material/AutoMode';
import LightModeIcon from '@mui/icons-material/LightMode';
import DarkModeIcon from '@mui/icons-material/DarkMode';
import ThemeContextProvider from './ThemeContext';


const Settings = () => {
    const { mode, setMode } = useContext(ThemeContextProvider);

    return (
        <div>
            <h2>Theme Settings</h2>
            <RadioGroup
                value={mode}
                onChange={(e) => setMode(e.target.value)}
                row
                >
                <FormControlLabel
                    value="auto"
                    control={<Radio />}
                    label={
                    <>
                    <AutoModeIcon sx={{ mx: 1}} />
                    Auto
                    </>
                    }
                    />
            </RadioGroup>
        </div>

    );
};

export default Settings;